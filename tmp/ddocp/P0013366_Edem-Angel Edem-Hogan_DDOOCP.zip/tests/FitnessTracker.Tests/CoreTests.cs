using Xunit;
namespace FitnessTracker.Tests;
public class CoreTests
{
    [Fact]
    public void password_accepts_twelve_mixed_letters()
    {
        Assert.True(Rules.password_ok("Abcdefghijkl"));
        Assert.False(Rules.password_ok("abcdefghijkl"));
        Assert.False(Rules.password_ok("Abcdefghijk"));
    }
    [Fact]
    public void username_rejects_space_and_empty()
    {
        Assert.True(Rules.username_ok("Alex01"));
        Assert.False(Rules.username_ok("Alex 01"));
        Assert.False(Rules.username_ok(""));
    }
    [Fact]
    public void calories_match_oracle()
    {
        Assert.Equal(141.75, new Walking().calories(new[] { 4000d, 3, 30 }));
        Assert.Equal(213.15, new Swimming().calories(new[] { 20d, 30, 120 }));
        Assert.Equal(386.75, new Running().calories(new[] { 5d, 30, 0 }));
        Assert.Equal(294.00, new Cycling().calories(new[] { 10d, 30, 110 }));
        Assert.Equal(134.75, new JumpRope().calories(new[] { 2000d, 10, 140 }));
        Assert.Equal(85.75, new Weights().calories(new[] { 3d, 12, 20 }));
    }
    [Fact]
    public void calories_reject_bad_metrics()
    {
        Assert.Throws<ArgumentException>(() => new Walking().calories(new[] { 100d, 3, 30 }));
        Assert.Throws<ArgumentException>(() => new Swimming().calories(new[] { 20d, 30, 10 }));
        Assert.Throws<ArgumentException>(() => new Running().calories(new[] { 5d, 0, 0 }));
    }
    private static AccountBook book_in(string dir) => new(new FileCabinet(dir));
    [Fact]
    public void register_login_and_lock()
    {
        string dir = Path.Combine(Path.GetTempPath(), "ft-" + Guid.NewGuid().ToString("N"));
        AccountBook book = book_in(dir);
        book.register("Alex01", "Abcdefghijkl");
        Assert.Throws<ArgumentException>(() => book.register("alex01", "Abcdefghijkl"));
        for (int i = 0; i < 5; i++)
            Assert.Throws<ArgumentException>(() => book.login("Alex01", "WrongPasswrd"));
        Assert.Throws<ArgumentException>(() => book.login("Alex01", "Abcdefghijkl"));
        User stored = new FileCabinet(dir).load().Single();
        Assert.True(stored.g > DateTimeOffset.UtcNow);
        Assert.True(stored.g <= DateTimeOffset.UtcNow.AddSeconds(30));
        stored.g = DateTimeOffset.UtcNow.AddSeconds(-1);
        new FileCabinet(dir).save(new List<User> { stored });
        AccountBook again = book_in(dir);
        again.login("Alex01", "Abcdefghijkl");
        Assert.Equal("Alex01", again.current!.a);
    }
    [Fact]
    public void goals_and_records_stay_per_user()
    {
        string dir = Path.Combine(Path.GetTempPath(), "ft-" + Guid.NewGuid().ToString("N"));
        AccountBook first = book_in(dir);
        first.register("Alex01", "Abcdefghijkl");
        first.register("Maya7", "ZyxwvutsrqpO");
        first.login("Alex01", "Abcdefghijkl");
        first.save_goal(141.75);
        first.record(new Walking(), new[] { 4000d, 3, 30 });
        Assert.True(first.met());
        first.logout();
        first.login("Maya7", "ZyxwvutsrqpO");
        first.save_goal(500);
        Assert.Equal(0, first.total());
        Assert.False(first.met());
        AccountBook reopened = book_in(dir);
        reopened.login("Alex01", "Abcdefghijkl");
        Assert.Equal(141.75, reopened.current!.d);
        Assert.Equal(141.75, reopened.total());
        Assert.Single(reopened.current.e);
    }
}
