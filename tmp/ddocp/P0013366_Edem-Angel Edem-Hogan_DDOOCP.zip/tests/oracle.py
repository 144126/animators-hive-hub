#!/usr/bin/env python3
from pathlib import Path
import json

def kcal_from_vo2(vo2, minutes):
    return round(vo2 * 70 / 1000 * 5 * minutes, 2)

def kcal_from_met(met, minutes):
    return round(met * 3.5 * 70 / 200 * minutes, 2)

def walking(steps, km, minutes):
    if minutes <= 0 or minutes > 180 or km <= 0 or km > 80 or not (1 <= steps <= 200000):
        raise ValueError("bad walk")
    stride = km * 1000 / steps
    if stride < 0.35 or stride > 1.20:
        raise ValueError("stride")
    return kcal_from_vo2(3.5 + 0.1 * (km * 1000 / minutes), minutes)

def swimming(laps, minutes, hr):
    if not (1 <= laps <= 400) or not (0.5 <= minutes <= 180) or not (40 <= hr <= 220):
        raise ValueError("bad swim")
    yds = laps * 25 * 1.09361 / minutes
    met = 5.8 if yds < 30 else 8.0 if yds < 50 else 10.5
    return kcal_from_met(met, minutes)

def running(km, minutes, elev):
    if minutes <= 0 or minutes > 180 or km <= 0 or km > 80 or elev < 0 or elev > 3000:
        raise ValueError("bad run")
    speed = km * 1000 / minutes
    grade = elev / (km * 1000)
    return kcal_from_vo2(3.5 + 0.2 * speed + 0.9 * speed * grade, minutes)

def cycling(km, minutes, hr):
    if km <= 0 or km > 200 or minutes <= 0 or minutes > 300 or not (40 <= hr <= 220):
        raise ValueError("bad cycle")
    mph = km / (minutes / 60) / 1.609344
    met = 4.0 if mph < 10 else 6.8 if mph < 12 else 8.0 if mph < 14 else 10.0 if mph < 16 else 12.0
    return kcal_from_met(met, minutes)

def jump_rope(jumps, minutes, hr):
    if not (20 <= jumps <= 20000) or minutes <= 0 or minutes > 60 or not (40 <= hr <= 220):
        raise ValueError("bad rope")
    rate = jumps / minutes
    if rate < 40 or rate > 280:
        raise ValueError("rate")
    return kcal_from_met(11.0, minutes)

def weights(sets, reps, minutes):
    if not (1 <= sets <= 30) or not (1 <= reps <= 50) or not (1 <= minutes <= 180):
        raise ValueError("bad weights")
    met = 3.5 if sets * reps <= 80 else 6.0
    return kcal_from_met(met, minutes)

def must_fail(fn, *args):
    try:
        fn(*args)
    except ValueError:
        return True
    raise SystemExit(f"expected reject: {fn.__name__}{args}")

vals = {
    "walking": walking(4000, 3, 30),
    "swimming": swimming(20, 30, 120),
    "running": running(5, 30, 0),
    "cycling": cycling(10, 30, 110),
    "jump_rope": jump_rope(2000, 10, 140),
    "weights": weights(3, 12, 20),
}
expect = {
    "walking": 141.75,
    "swimming": 213.15,
    "running": 386.75,
    "cycling": 294.00,
    "jump_rope": 134.75,
    "weights": 85.75,
}
for k, v in expect.items():
    if abs(vals[k] - v) > 1e-9:
        raise SystemExit(f"{k} {vals[k]} != {v}")
must_fail(walking, 100, 3, 30)
must_fail(swimming, 20, 30, 10)
must_fail(running, 5, 0, 0)
out = {**vals, "ok": True, "rejects": ["walk stride", "swim hr 10", "run zero minutes"]}
Path("evidence").mkdir(exist_ok=True)
Path("evidence/oracle.json").write_text(json.dumps(out, indent=2) + "\n")
print("ok")
