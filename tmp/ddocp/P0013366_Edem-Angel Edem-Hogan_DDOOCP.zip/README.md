# Fitness Tracker — Edem Angel Edem Hogan (P0013366)

Open `FitnessTracker.sln` in Visual Studio on Windows with the .NET 8 desktop workload.
Build and run the `FitnessTracker` WinForms project. Data is `%LOCALAPPDATA%\FitnessTracker\users.json`.
On this Linux box: `./run-linux.sh` (GTK port of the same form).

Username: letters and numbers only. Password: exactly 12 characters, with at least one lowercase and one uppercase letter. Five failed sign-ins lock the account for 30 seconds.

Activities and metrics:

- Walking — Steps, Distance (km), Time (minutes)
- Swimming — Laps (25 m), Time (minutes), Average heart rate (bpm)
- Running — Distance (km), Time (minutes), Elevation gain (m)
- Cycling — Distance (km), Time (minutes), Average heart rate (bpm)
- Jump rope — Jumps, Time (minutes), Average heart rate (bpm)
- Weights — Sets, Repetitions, Time (minutes)

Estimates use a 70 kg reference person. They are not medical measurements.
The written report is `report/P0013366_Edem-Angel Edem-Hogan_Designing and Developing Object-Oriented Computer Programs.docx`.
