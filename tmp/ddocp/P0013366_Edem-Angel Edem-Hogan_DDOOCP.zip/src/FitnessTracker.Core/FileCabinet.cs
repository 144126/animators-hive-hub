using System.Text.Json;
namespace FitnessTracker;
public sealed class FileCabinet
{
    private readonly string path;
    public FileCabinet(string? dir = null)
    {
        string folder = dir ?? Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FitnessTracker");
        path = Path.Combine(folder, "users.json");
    }
    public List<User> load()
    {
        if (!File.Exists(path)) return new();
        try
        {
            return JsonSerializer.Deserialize<List<User>>(File.ReadAllText(path))
                ?? throw new InvalidDataException("The saved account file is empty or invalid.");
        }
        catch (JsonException)
        {
            throw new InvalidDataException("The saved account file is empty or invalid.");
        }
    }
    public void save(List<User> users)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        File.WriteAllText(path + ".tmp", JsonSerializer.Serialize(users));
        File.Move(path + ".tmp", path, true);
    }
}
