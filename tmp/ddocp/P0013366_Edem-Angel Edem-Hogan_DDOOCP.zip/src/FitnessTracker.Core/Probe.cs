namespace FitnessTracker;
public static class Probe { }
