namespace FitnessTracker;
public sealed class User
{
    public string a { get; set; } = ""; // Username.
    public string b { get; set; } = ""; // Password salt, Base64.
    public string c { get; set; } = ""; // Password hash, Base64.
    public double d { get; set; } = 300; // Calorie goal.
    public List<ActivityRecord> e { get; set; } = new(); // Saved activity records.
    public int f { get; set; } // Consecutive failed logins.
    public DateTimeOffset g { get; set; } // Lock expiry UTC.
}
public sealed class ActivityRecord
{
    public string a { get; set; } = ""; // Activity name.
    public double[] b { get; set; } = Array.Empty<double>(); // Three metric values.
    public double c { get; set; } // Estimated calories.
    public DateTimeOffset d { get; set; } // Record time UTC.
}
