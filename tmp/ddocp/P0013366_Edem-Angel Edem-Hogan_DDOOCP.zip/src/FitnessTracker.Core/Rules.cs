using System.Text.RegularExpressions;
namespace FitnessTracker;
public static class Rules
{
    public static bool username_ok(string name) =>
        Regex.IsMatch(name, "^[A-Za-z0-9]{1,32}$");
    public static bool password_ok(string password) =>
        password.Length == 12 && password.Any(char.IsLower) && password.Any(char.IsUpper);
    public static bool goal_ok(double goal) =>
        double.IsFinite(goal) && goal >= 1 && goal <= 10000;
    public static void require(bool ok, string message)
    {
        if (!ok) throw new ArgumentException(message);
    }
}
