namespace FitnessTracker;
public abstract class Activity
{
    public abstract string name { get; }
    public abstract string[] labels { get; }
    public abstract double calories(double[] m);
    protected static void need(double[] m)
    {
        if (m.Length != 3 || m.Any(v => !double.IsFinite(v)))
            throw new ArgumentException("Enter three valid numbers.");
    }
    protected static double kcal_from_vo2(double vo2, double minutes) =>
        Math.Round(vo2 * 70 / 1000 * 5 * minutes, 2);
    protected static double kcal_from_met(double met, double minutes) =>
        Math.Round(met * 3.5 * 70 / 200 * minutes, 2);
    protected static void need_hr(double hr)
    {
        if (hr < 40 || hr > 220) throw new ArgumentException("Heart rate must be between 40 and 220 bpm.");
    }
    public static Activity[] all() => new Activity[]
    {
        new Walking(), new Swimming(), new Running(), new Cycling(), new JumpRope(), new Weights()
    };
    public static Activity by_id(string id) => id switch
    {
        "walking" => new Walking(),
        "swimming" => new Swimming(),
        "running" => new Running(),
        "cycling" => new Cycling(),
        "jump_rope" => new JumpRope(),
        "weights" => new Weights(),
        _ => throw new ArgumentException("Unknown activity.")
    };
}
public sealed class Walking : Activity
{
    public override string name => "Walking";
    public override string[] labels => new[] { "Steps", "Distance (km)", "Time (minutes)" };
    public override double calories(double[] m)
    {
        need(m);
        double steps = m[0], km = m[1], minutes = m[2];
        if (minutes <= 0 || minutes > 180) throw new ArgumentException("Time must be above zero and at most 180 minutes.");
        if (km <= 0 || km > 80) throw new ArgumentException("Distance must be above zero and at most 80 km.");
        if (steps < 1 || steps > 200000) throw new ArgumentException("Steps must be between 1 and 200000.");
        double stride = km * 1000 / steps;
        if (stride < 0.35 || stride > 1.20) throw new ArgumentException("Step length is outside 0.35–1.20 m.");
        return kcal_from_vo2(3.5 + 0.1 * (km * 1000 / minutes), minutes);
    }
}
public sealed class Running : Activity
{
    public override string name => "Running";
    public override string[] labels => new[] { "Distance (km)", "Time (minutes)", "Elevation gain (m)" };
    public override double calories(double[] m)
    {
        need(m);
        double km = m[0], minutes = m[1], elev = m[2];
        if (minutes <= 0 || minutes > 180) throw new ArgumentException("Time must be above zero and at most 180 minutes.");
        if (km <= 0 || km > 80) throw new ArgumentException("Distance must be above zero and at most 80 km.");
        if (elev < 0 || elev > 3000) throw new ArgumentException("Elevation must be between 0 and 3000 m.");
        double speed = km * 1000 / minutes;
        double grade = elev / (km * 1000);
        return kcal_from_vo2(3.5 + 0.2 * speed + 0.9 * speed * grade, minutes);
    }
}
public sealed class Swimming : Activity
{
    public override string name => "Swimming";
    public override string[] labels => new[] { "Laps (25 m)", "Time (minutes)", "Average heart rate (bpm)" };
    public override double calories(double[] m)
    {
        need(m);
        double laps = m[0], minutes = m[1], hr = m[2];
        if (laps < 1 || laps > 400) throw new ArgumentException("Laps must be between 1 and 400.");
        if (minutes < 0.5 || minutes > 180) throw new ArgumentException("Time must be between 0.5 and 180 minutes.");
        need_hr(hr);
        double yds_per_min = laps * 25 * 1.09361 / minutes;
        double met = yds_per_min < 30 ? 5.8 : yds_per_min < 50 ? 8.0 : 10.5; // 18240 / 18290 / 18280
        return kcal_from_met(met, minutes);
    }
}
public sealed class Cycling : Activity
{
    public override string name => "Cycling";
    public override string[] labels => new[] { "Distance (km)", "Time (minutes)", "Average heart rate (bpm)" };
    public override double calories(double[] m)
    {
        need(m);
        double km = m[0], minutes = m[1], hr = m[2];
        if (km <= 0 || km > 200) throw new ArgumentException("Distance must be above zero and at most 200 km.");
        if (minutes <= 0 || minutes > 300) throw new ArgumentException("Time must be above zero and at most 300 minutes.");
        need_hr(hr);
        double mph = km / (minutes / 60) / 1.609344;
        double met = mph < 10 ? 4.0 : mph < 12 ? 6.8 : mph < 14 ? 8.0 : mph < 16 ? 10.0 : 12.0; // 01010-01050
        return kcal_from_met(met, minutes);
    }
}
public sealed class JumpRope : Activity
{
    public override string name => "Jump rope";
    public override string[] labels => new[] { "Jumps", "Time (minutes)", "Average heart rate (bpm)" };
    public override double calories(double[] m)
    {
        need(m);
        double jumps = m[0], minutes = m[1], hr = m[2];
        if (jumps < 20 || jumps > 20000) throw new ArgumentException("Jumps must be between 20 and 20000.");
        if (minutes <= 0 || minutes > 60) throw new ArgumentException("Time must be above zero and at most 60 minutes.");
        need_hr(hr);
        double rate = jumps / minutes;
        if (rate < 40 || rate > 280) throw new ArgumentException("Jump rate must be between 40 and 280 per minute.");
        return kcal_from_met(11.0, minutes); // 02068
    }
}
public sealed class Weights : Activity
{
    public override string name => "Weights";
    public override string[] labels => new[] { "Sets", "Repetitions", "Time (minutes)" };
    public override double calories(double[] m)
    {
        need(m);
        double sets = m[0], reps = m[1], minutes = m[2];
        if (sets < 1 || sets > 30) throw new ArgumentException("Sets must be between 1 and 30.");
        if (reps < 1 || reps > 50) throw new ArgumentException("Repetitions must be between 1 and 50.");
        if (minutes < 1 || minutes > 180) throw new ArgumentException("Time must be between 1 and 180 minutes.");
        double met = sets * reps <= 80 ? 3.5 : 6.0; // 02054 / 02050
        return kcal_from_met(met, minutes);
    }
}
