using System.Security.Cryptography;
namespace FitnessTracker;
public sealed class AccountBook
{
    private readonly FileCabinet store;
    private readonly List<User> users;
    public User? current { get; private set; }
    public AccountBook(FileCabinet? store = null)
    {
        this.store = store ?? new FileCabinet();
        users = this.store.load();
    }
    private static byte[] derive(string password, byte[] salt) =>
        Rfc2898DeriveBytes.Pbkdf2(password, salt, 210000, HashAlgorithmName.SHA256, 32);
    public void register(string name, string password)
    {
        Rules.require(Rules.username_ok(name), "Use 1–32 letters and numbers for the username.");
        Rules.require(Rules.password_ok(password), "Use exactly 12 password characters. Include lowercase and uppercase letters.");
        if (users.Any(u => string.Equals(u.a, name, StringComparison.OrdinalIgnoreCase)))
            throw new ArgumentException("That username is already in use.");
        byte[] salt = RandomNumberGenerator.GetBytes(16);
        users.Add(new User { a = name, b = Convert.ToBase64String(salt), c = Convert.ToBase64String(derive(password, salt)) });
        store.save(users);
    }
    public void login(string name, string password)
    {
        User? user = users.FirstOrDefault(u => string.Equals(u.a, name, StringComparison.OrdinalIgnoreCase));
        if (user is null) throw new ArgumentException("Check your username and password.");
        if (user.g > DateTimeOffset.UtcNow) throw new ArgumentException("This account is locked. Wait 30 seconds before retrying.");
        byte[] expected = Convert.FromBase64String(user.c);
        byte[] got = derive(password, Convert.FromBase64String(user.b));
        if (!CryptographicOperations.FixedTimeEquals(expected, got))
        {
            user.f++;
            if (user.f >= 5) user.g = DateTimeOffset.UtcNow.AddSeconds(30);
            store.save(users);
            throw new ArgumentException(user.f >= 5 ? "This account is locked for 30 seconds." : "Check your username and password.");
        }
        user.f = 0;
        user.g = default;
        current = user;
        store.save(users);
    }
    public void logout() { current = null; }
    public void save_goal(double goal)
    {
        if (current is null) throw new InvalidOperationException("Sign in first.");
        Rules.require(Rules.goal_ok(goal), "Enter a goal between 1 and 10000.");
        current.d = goal;
        store.save(users);
    }
    public void record(Activity activity, double[] metrics)
    {
        if (current is null) throw new InvalidOperationException("Sign in first.");
        current.e.Add(new ActivityRecord { a = activity.name, b = metrics, c = activity.calories(metrics), d = DateTimeOffset.UtcNow });
        store.save(users);
    }
    public double total() => current?.e.Sum(r => r.c) ?? 0;
    public bool met() => current is not null && total() >= current.d;
}
