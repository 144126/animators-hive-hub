using System.Globalization;
namespace FitnessTracker;
public sealed class TrackerForm : Form
{
    private readonly TextBox username = new();
    private readonly TextBox password = new();
#if WINDOWS
    private void hide_password() { password.UseSystemPasswordChar = true; }
#else
    // Gtk.Windows.Forms PasswordChar makes Text return the mask, so login always fails.
    private void hide_password() { }
#endif
    private readonly TextBox goal = new();
    private readonly ComboBox activity = new() { DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox[] metrics = { new(), new(), new() };
    private readonly Label[] metric_labels = { new(), new(), new() };
    private readonly Label progress = new() { AutoSize = true };
    private readonly Label login_status = new() { AutoSize = true, MaximumSize = new Size(640, 0) };
    private readonly Label work_status = new() { AutoSize = true, MaximumSize = new Size(640, 0) };
    private readonly Label signed_in = new() { AutoSize = true };
    private readonly ListBox records = new() { Width = 640, Height = 140 };
    private readonly Panel login_panel = new() { Dock = DockStyle.Fill, AutoScroll = true };
    private readonly Panel work_panel = new() { Dock = DockStyle.Fill, AutoScroll = true, Visible = false };
    private readonly Activity[] activities = Activity.all();
    private readonly AccountBook book;
    public TrackerForm()
    {
        Text = "Fitness Tracker";
        Width = 720;
        Height = 640;
        MinimumSize = new Size(680, 600);
        hide_password();
        try { book = new AccountBook(); }
        catch (Exception error)
        {
            MessageBox.Show("Cannot load account data. " + error.Message);
            throw;
        }
        Controls.Add(work_panel);
        Controls.Add(login_panel);
        build_login();
        build_work();
        show_login();
    }
    private void build_login()
    {
        FlowLayoutPanel col = column();
        login_panel.Controls.Add(col);
        add_field(col, "Username", username);
        add_field(col, "Password: exactly 12 characters", password);
        FlowLayoutPanel buttons = new() { Width = 640, Height = 40 };
        add_button(buttons, "Register", () => { book.register(box_text(username), box_text(password)); password.Clear(); say(login_status, "Account created. Sign in."); }, login_status);
        add_button(buttons, "Sign in", () => { book.login(box_text(username), box_text(password)); password.Clear(); show_work(); }, login_status);
        col.Controls.Add(buttons);
        col.Controls.Add(login_status);
    }
    private void build_work()
    {
        FlowLayoutPanel col = column();
        work_panel.Controls.Add(col);
        col.Controls.Add(signed_in);
        add_field(col, "Calorie goal", goal);
        add_button(col, "Save goal", () => { book.save_goal(parse(box_text(goal))); refresh(); say(work_status, "Goal saved."); }, work_status);
        activity.Items.AddRange(activities.Select(a => (object)a.name).ToArray());
        activity.SelectedIndexChanged += (_, _) =>
        {
            for (int i = 0; i < 3; i++)
            {
                metric_labels[i].Text = activities[activity.SelectedIndex].labels[i];
                metrics[i].Clear();
            }
        };
        add_field(col, "Activity", activity);
        for (int i = 0; i < 3; i++)
        {
            metric_labels[i].AutoSize = true;
            col.Controls.Add(metric_labels[i]);
            metrics[i].Width = 300;
            col.Controls.Add(metrics[i]);
        }
        activity.SelectedIndex = 0;
        add_button(col, "Record", () => { book.record(activities[activity.SelectedIndex], metrics.Select(m => parse(box_text(m))).ToArray()); refresh(); say(work_status, "Activity saved."); }, work_status);
        col.Controls.Add(progress);
        col.Controls.Add(records);
        add_button(col, "Sign out", () => { book.logout(); show_login(); }, work_status);
        col.Controls.Add(new Label { AutoSize = true, MaximumSize = new Size(640, 0), Text = "Estimates use a 70 kg reference person. They are not medical measurements." });
        col.Controls.Add(work_status);
    }
    private static FlowLayoutPanel column() =>
        new() { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, Padding = new Padding(20) };
    private static void add_field(Control parent, string text, Control input)
    {
        parent.Controls.Add(new Label { Text = text, AutoSize = true });
        input.Width = 300;
        parent.Controls.Add(input);
    }
    private static string box_text(TextBox box) => box.Text ?? "";
    private static void say(Label target, string text) { target.Text = text; target.Visible = true; }
    private void add_button(Control parent, string text, Action action, Label status)
    {
        Button button = new() { Text = text, Width = 110, Height = 32 };
        button.Click += (_, _) => { try { action(); } catch (Exception error) { say(status, error.Message); } };
        parent.Controls.Add(button);
        button.Tag = action;
    }
    private static double parse(string value)
    {
        if (!double.TryParse(value, NumberStyles.Float, CultureInfo.CurrentCulture, out double number))
            throw new ArgumentException("Enter a number in each required field.");
        return number;
    }
    private void show_login()
    {
        work_panel.Visible = false;
        login_panel.Visible = true;
        records.Items.Clear();
        progress.Text = "";
        login_status.Text = "";
        work_status.Text = "";
    }
    private void show_work()
    {
        login_panel.Visible = false;
        work_panel.Visible = true;
        refresh();
        say(work_status, "Signed in.");
    }
    private void refresh()
    {
        if (book.current is null) return;
        signed_in.Text = book.current.a;
        goal.Text = book.current.d.ToString(CultureInfo.CurrentCulture);
        progress.Text = $"{book.current.a}: {book.total():F2} / {book.current.d:F2} calories. " + (book.met() ? "Goal achieved." : "Goal not yet achieved.");
        records.Items.Clear();
        foreach (ActivityRecord entry in book.current.e)
            records.Items.Add($"{entry.d.LocalDateTime:g} — {entry.a} — {entry.c:F2} calories");
    }
    public void shot_fill_login(string name, string secret)
    {
        username.Text = name;
        password.Text = secret;
        username.Refresh();
        password.Refresh();
        Update();
    }
    public void shot_register() { click_named("Register"); }
    public void shot_signin() { click_named("Sign in"); }
    public void shot_save_goal(string value)
    {
        goal.Text = value;
        click_named("Save goal");
    }
    public void shot_walk(string steps, string km, string minutes)
    {
        activity.SelectedIndex = 0;
        metrics[0].Text = steps;
        metrics[1].Text = km;
        metrics[2].Text = minutes;
        click_named("Record");
    }
    void click_named(string text)
    {
        foreach (Control child in walk(this))
        {
            if (child is Button button && button.Text == text && button.Tag is Action action)
            {
                try { action(); } catch (Exception error) { say(login_panel.Visible ? login_status : work_status, error.Message); }
                return;
            }
        }
        throw new InvalidOperationException("missing " + text);
    }
    static IEnumerable<Control> walk(Control root)
    {
        foreach (Control child in root.Controls)
        {
            yield return child;
            foreach (Control inner in walk(child)) yield return inner;
        }
    }
}
