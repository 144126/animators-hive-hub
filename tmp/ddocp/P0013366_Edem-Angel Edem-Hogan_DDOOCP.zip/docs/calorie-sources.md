# Calorie sources

Estimates use a 70 kg reference person. They are not a medical measurement.

kcal from VO2 = VO2 × 70 / 1000 × 5 × minutes, rounded to 2 dp.
kcal from MET = MET × 3.5 × 70 / 200 × minutes (same arithmetic).

| Activity | Metrics | Formula | Check |
|---|---|---|---|
| Walking | Steps, Distance (km), Time (minutes) | ACSM walk, grade 0: VO2 = 3.5 + 0.1 × (km×1000/minutes). Stride must be 0.35–1.20 m. Glass and Gregory (2007). | 4000, 3, 30 → 141.75 |
| Swimming | Laps (25 m), Time (minutes), Average heart rate (bpm) | yd/min = laps×25×1.09361/minutes. MET 5.8 if <30 (18240), 8.0 if <50 (18290), else 10.5 (18280). Herrmann et al. (2024). | 20, 30, 120 → 213.15 |
| Running | Distance (km), Time (minutes), Elevation gain (m) | ACSM run: VO2 = 3.5 + 0.2×speed + 0.9×speed×(elev/distance). Glass and Gregory (2007). | 5, 30, 0 → 386.75 |
| Cycling | Distance (km), Time (minutes), Average heart rate (bpm) | mph from km and minutes. MET 4.0 / 6.8 / 8.0 / 10.0 / 12.0 (01010–01050). Herrmann et al. (2024). | 10, 30, 110 → 294.00 |
| Jump rope | Jumps, Time (minutes), Average heart rate (bpm) | MET 11.0 (02068). Rate 40–280 jumps/min. Herrmann et al. (2024). | 2000, 10, 140 → 134.75 |
| Weights | Sets, Repetitions, Time (minutes) | MET 3.5 (02054) if sets×reps ≤ 80, else 6.0 (02050). Herrmann et al. (2024). | 3, 12, 20 → 85.75 |

Herrmann, S.D., Willis, E.A., Ainsworth, B.E. et al. (2024) 2024 Adult Compendium of Physical Activities. Available at: https://pacompendium.com/ (Accessed: 7 October 2026).

Glass, S. and Gregory, B. (2007) ACSM's Metabolic Calculations Handbook. Baltimore: Lippincott Williams & Wilkins.
